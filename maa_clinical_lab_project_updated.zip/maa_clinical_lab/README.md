# MAA Clinical Laboratory — Free-tier Deployable Scaffold

## What this includes
- Next.js + TypeScript + Tailwind-ready scaffold (app router)
- Supabase client setup (Auth, Storage)
- Admin login (email/password) + admin-protected pages
- Tests CRUD with price-history
- Report upload to Supabase Storage + signed URL generation
- `.env.example`, SQL schema, and deployment instructions

## Defaults used
- Lab name: MAA CLINICAL LABORATORY
- Admin email: maaclinic092@gmail.com
- Admin password: LABORATORY

## Quick start (local / deploy)
1. Create a Supabase project (free) at https://supabase.com
2. In Supabase SQL editor, run the SQL in `supabase_schema.sql` included in this repo.
3. Create a Storage bucket named `reports` (private).
4. Create an Auth user with the admin email and password above from Supabase Dashboard -> Authentication -> Users.
   Then set their profile role to `admin` in `profiles` table (see SQL).
5. Copy `.env.example` to `.env.local` and set the values from your Supabase project.
6. Install and run locally:
   ```bash
   npm install
   npm run dev
   ```
7. Deploy: push this repo to GitHub and import to Vercel. Add the same env vars in Vercel project settings.

## Files of interest
- `app/` — Next.js pages (home, admin login, dashboard, tests, reports)
- `lib/supabaseClient.ts` — Supabase client
- `supabase_schema.sql` — SQL to create tables
- `.env.example` — env var template

## Notes
- This scaffold uses client-side role checks for admin convenience. For production, enforce server-side RLS and service-role signed URL generation.
- If you want me to add your real logo, upload it here and I'll place it in `/public/logo.png` and update the home page.

