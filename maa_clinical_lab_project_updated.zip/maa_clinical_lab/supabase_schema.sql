-- Supabase schema for MAA Clinical Laboratory (paste into Supabase SQL editor)
create extension if not exists pgcrypto;

create table if not exists public.tests (
  id uuid primary key default gen_random_uuid(),
  code text unique,
  name text not null,
  description text,
  created_at timestamptz default now()
);

create table if not exists public.test_prices (
  id uuid primary key default gen_random_uuid(),
  test_id uuid references public.tests(id) on delete cascade,
  price numeric not null,
  effective_from timestamptz default now(),
  changed_by uuid,
  created_at timestamptz default now()
);

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  patient_name text,
  patient_phone text,
  patient_email text,
  test_id uuid references public.tests(id),
  scheduled_at timestamptz,
  status text default 'pending',
  created_at timestamptz default now()
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid references public.bookings(id) on delete cascade,
  storage_path text not null,
  uploaded_by uuid,
  uploaded_at timestamptz default now()
);

create table if not exists public.profiles (
  id uuid references auth.users(id) primary key,
  full_name text,
  role text default 'staff'
);
