'use client'
import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabaseClient'

export default function ReportsAdmin() {
  const [bookings, setBookings] = useState<any[]>([])
  const [file, setFile] = useState<File | null>(null)
  const [selBooking, setSelBooking] = useState('')

  const loadBookings = async () => {
    const { data } = await supabase.from('bookings').select('*').order('created_at', { ascending:false })
    setBookings(data || [])
  }

  useEffect(()=>{ loadBookings() }, [])

  const upload = async () => {
    if (!file || !selBooking) return alert('Select booking and file')
    const path = `reports/${Date.now()}_${file.name}`
    const { error: upErr } = await supabase.storage.from('reports').upload(path, file)
    if (upErr) return alert(upErr.message)
    // save record
    await supabase.from('reports').insert({ booking_id: selBooking, storage_path: path })
    alert('Uploaded')
    setFile(null); setSelBooking('')
    loadBookings()
  }

  const genLink = async (path:string) => {
    const { data } = await supabase.storage.from('reports').createSignedUrl(path, 60*60) // 1 hour
    if (data?.signedUrl) window.open(data.signedUrl, '_blank')
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Upload Reports</h1>

      <div className="mb-4 bg-white p-4 rounded shadow">
        <select className="border p-2 w-full mb-2" value={selBooking} onChange={e=>setSelBooking(e.target.value)}>
          <option value="">Select booking</option>
          {bookings.map(b => <option key={b.id} value={b.id}>{b.patient_name} — {b.id}</option>)}
        </select>
        <input type="file" accept="application/pdf" onChange={e=>setFile(e.target.files?.[0]||null)} />
        <div className="mt-3">
          <button className="bg-blue-600 text-white px-4 py-2 rounded" onClick={upload}>Upload PDF</button>
        </div>
      </div>

      <h2 className="text-xl font-semibold mb-2">Existing Reports</h2>
      <div className="space-y-2">
        <ReportsList onOpen={genLink} />
      </div>
    </div>
  )
}

function ReportsList({ onOpen }: { onOpen: (path:string)=>void }) {
  const [reports, setReports] = useState<any[]>([])
  useEffect(()=>{
    (async()=>{
      const { data } = await supabase.from('reports').select('id, storage_path, uploaded_at, booking_id')
      setReports(data || [])
    })()
  },[])

  return (
    <div>
      {reports.map(r => (
        <div key={r.id} className="p-2 bg-white rounded flex justify-between items-center">
          <div>
            <div className="text-sm">Booking: {r.booking_id}</div>
            <div className="text-xs text-gray-500">Uploaded: {new Date(r.uploaded_at).toLocaleString()}</div>
          </div>
          <div>
            <button className="px-3 py-1 border rounded" onClick={()=>onOpen(r.storage_path)}>Open</button>
          </div>
        </div>
      ))}
    </div>
  )
}
