'use client'
import { useState } from 'react'
import { supabase } from '@/lib/supabaseClient'

export default function AdminLogin() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [err, setErr] = useState('')

  const login = async () => {
    setErr('')
    const { data, error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) return setErr(error.message)
    // check role
    const { data: profile } = await supabase.from('profiles').select('role').eq('id', data.user?.id).single()
    if (profile?.role !== 'admin') {
      setErr('Not authorized as admin')
      await supabase.auth.signOut()
      return
    }
    window.location.href = '/admin/dashboard'
  }

  return (
    <div className="max-w-md mx-auto p-6">
      <h2 className="text-2xl font-bold mb-4">Admin Login</h2>
      <input className="w-full p-2 border mb-3" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
      <input type="password" className="w-full p-2 border mb-3" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} />
      <button className="w-full bg-blue-600 text-white p-2 rounded" onClick={login}>Login</button>
      {err && <p className="text-red-600 mt-3">{err}</p>}
    </div>
  )
}
