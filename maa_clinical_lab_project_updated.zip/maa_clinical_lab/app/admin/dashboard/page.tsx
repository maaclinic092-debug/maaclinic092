import Link from 'next/link'

export default function Dashboard() {
  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">Admin Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Link href="/admin/tests" className="p-4 bg-white shadow rounded">Manage Tests</Link>
        <Link href="/admin/reports" className="p-4 bg-white shadow rounded">Upload/View Reports</Link>
        <Link href="/admin/bookings" className="p-4 bg-white shadow rounded">View Bookings</Link>
      </div>
    </div>
  )
}
