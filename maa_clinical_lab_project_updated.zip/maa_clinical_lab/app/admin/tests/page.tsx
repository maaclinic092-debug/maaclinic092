'use client'
import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabaseClient'

export default function AdminTests() {
  const [tests, setTests] = useState<any[]>([])
  const [name, setName] = useState('')
  const [price, setPrice] = useState('')

  const load = async () => {
    const { data } = await supabase.from('tests').select('*, test_prices(*)').order('created_at', { ascending: false })
    setTests(data || [])
  }

  useEffect(()=>{ load() }, [])

  const addTest = async () => {
    if (!name || !price) return alert('Enter name and price')
    const { data: t } = await supabase.from('tests').insert({ name }).select().single()
    await supabase.from('test_prices').insert({ test_id: t.id, price })
    setName(''); setPrice('')
    load()
  }

  const addPrice = async (testId:string) => {
    const p = prompt('Enter new price')
    if (!p) return
    await supabase.from('test_prices').insert({ test_id: testId, price: p })
    load()
  }

  const delTest = async (id:string) => {
    if (!confirm('Delete test?')) return
    await supabase.from('tests').delete().eq('id', id)
    load()
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Manage Tests & Prices</h1>
      <div className="flex gap-2 mb-4">
        <input className="border p-2 flex-1" placeholder="Test name" value={name} onChange={e=>setName(e.target.value)} />
        <input className="border p-2 w-32" placeholder="Price" value={price} onChange={e=>setPrice(e.target.value)} />
        <button className="bg-green-600 text-white px-3 rounded" onClick={addTest}>Add</button>
      </div>

      <div className="space-y-3">
        {tests.map(t => (
          <div key={t.id} className="p-3 bg-white rounded shadow flex justify-between">
            <div>
              <div className="font-medium">{t.name}</div>
              <div className="text-sm text-gray-600">Prices: {t.test_prices?.map(tp => `₹${tp.price}`).join(', ')}</div>
            </div>
            <div className="flex gap-2">
              <button className="px-3 py-1 border rounded" onClick={()=>addPrice(t.id)}>Add Price</button>
              <button className="px-3 py-1 border rounded" onClick={()=>delTest(t.id)}>Delete</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
