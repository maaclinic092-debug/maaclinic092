
import Link from 'next/link'

export default function Home() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center p-8">
      <img src="/logo.png" alt="Logo" className="w-36 h-36 mb-6" />
      <h1 className="text-4xl font-bold">MAA CLINICAL LABORATORY</h1>
      <p className="mt-3 text-lg text-center max-w-2xl">Trusted Diagnostic Services — Accurate, Fast, Reliable.</p>

      <div className="mt-6 space-x-3">
        <Link href="/admin/login" className="px-4 py-2 bg-blue-600 text-white rounded">Admin Login</Link>
        <Link href="/contact" className="px-4 py-2 border rounded">Contact Us</Link>
      </div>

      <section className="mt-12 text-center w-full px-4">
        <h2 className="text-2xl font-bold mb-4">Our Services</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="service-card p-6 bg-white shadow-md rounded-lg">
            <h3 className="font-semibold text-xl">Blood Tests</h3>
            <p className="mt-2 text-gray-700">Comprehensive blood tests for accurate diagnosis.</p>
          </div>
          <div className="service-card p-6 bg-white shadow-md rounded-lg">
            <h3 className="font-semibold text-xl">Urine Analysis</h3>
            <p className="mt-2 text-gray-700">Detailed urine analysis for health insights.</p>
          </div>
          <div className="service-card p-6 bg-white shadow-md rounded-lg">
            <h3 className="font-semibold text-xl">ECG & X-rays</h3>
            <p className="mt-2 text-gray-700">Advanced diagnostics with ECG and X-ray services.</p>
          </div>
        </div>
      </section>

      <section className="mt-12 text-center w-full px-4">
        <h2 className="text-2xl font-bold mb-4">Operating Hours</h2>
        <p className="text-lg text-gray-700">Monday - Saturday: 8:00 AM - 7:00 PM</p>
        <p className="text-lg text-gray-700">Sunday: Closed</p>
      </section>

      <section className="mt-12 text-center w-full px-4">
        <h2 className="text-2xl font-bold mb-4">Contact Us</h2>
        <p className="text-lg text-gray-700">Email: info@maaclinic.com</p>
        <p className="text-lg text-gray-700">Phone: +123 456 7890</p>
        <div className="mt-6">
          <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3559.4332301070087!2d80.24383211460743!3d13.080738118474735!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a52f50e2bda40db%3A0xe9b6bca978b9f96a!2sMAA%20CLINICAL%20LABORATORY!5e0!3m2!1sen!2sin!4v1609408627470!5m2!1sen!2sin"
            width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
        </div>
      </section>
    </main>
  )
}
